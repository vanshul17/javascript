// Group 1 - Problem starts here
addEventListener ('click', function group1_choice1() {
    let input = document.getElementById('q1_str1').value;

    if (!isNaN(input)) {
        let number = parseFloat(input);
        if (number === 0 || (number >= 13 && number <= 17)) {
            document.getElementById('q1_out1').value = "In range";
        } else {
            document.getElementById('q1_out1').value = "Out of range";
        }
    } else {
        document.getElementById('q1_out1').value = "Not a number";
    }
})


addEventListener ('click', function group1_choice3() {
    let input = document.getElementById('q2_str2').value;

    if (!isNaN(input)) {
        let side = parseFloat(input);
        if (side >= 0) {
            let perimeter = 4 * side;
            let area = side * side;
            document.getElementById('q2_out').value = `Perimeter: ${perimeter}, Area: ${area}`;
        } else {
            document.getElementById('q2_out').value = "Can't calculate";
        }
    } else {
        document.getElementById('q2_out').value = "Not a number";
    }
})

// Group 2 - Problem ends  here


// Group 2 - Problem starts here
addEventListener ('click', function group2_choice1() {
    let input = document.getElementById('str2').value.toLowerCase();

    if (input === "a" || input === "e" || input === "i" || input === "o" || input === "u") {
        document.getElementById('out2').value = "A Vowel";
    } else if (input === "y") {
        document.getElementById('out2').value = "Sometimes";
    } else {
        document.getElementById('out2').value = "Not a vowel";
    }
})


addEventListener ('click', function group2_choice3() {
    let input = document.getElementById('str12').value;

    if (!isNaN(input) && parseInt(input) >= 0) {
        let num = parseInt(input);
        let factorial = 1;

        for (let i = 1; i <= num; i++) {
            factorial *= i;
        }

        document.getElementById('out12').value = factorial;
    } else {
        document.getElementById('out12').value = "Cannot compute factorial value";
    }
})


// Group 2 - Problem ends here


// Group 3 - Problem starts here
addEventListener ('click', function group3_choice1() {
    let input = document.getElementById('string3').value;

    if (input.length >= 10 && input.length <= 20 && /^[01]+$/.test(input)) {
        let decimalValue = 0;

        for (let i = 0; i < input.length; i++) {
            decimalValue += parseInt(input[i]) * Math.pow(2, i);
        }

        document.getElementById('output3').value = decimalValue;
    } else {
        document.getElementById('output3').value = 0;
    }
})

// Group 3 - Problem ends here
