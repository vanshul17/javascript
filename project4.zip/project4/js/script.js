document.addEventListener("DOMContentLoaded", function() {
    const svg = document.getElementById("game-svg");
    const scoreDisplay = document.getElementById("score");
    const startButton = document.getElementById("start-btn");
    
    
    let score = 0;
    let gameStarted = false;
    let gameInterval;
    let shapes = [];

    function getRandomColor() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    function createRandomCircle() {
        const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        circle.setAttribute("cx", Math.random() * 500);
        circle.setAttribute("cy", Math.random() * 300);
        circle.setAttribute("r", 20);
        circle.setAttribute("fill", getRandomColor());

        circle.addEventListener("click", function(event) {
            if (gameStarted && event.target === circle) {
                score++;
                scoreDisplay.textContent = "Score: " + score;
                svg.removeChild(circle);
            }
        });

        svg.appendChild(circle);
        shapes.push({ element: circle, dx: Math.random() * 2 - 1, dy: Math.random() * 2 - 1 });
    }

    function createRandomSquare() {
        const square = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        square.setAttribute("x", Math.random() * 500);
        square.setAttribute("y", Math.random() * 300);
        square.setAttribute("width", 30);
        square.setAttribute("height", 30);
        square.setAttribute("fill", getRandomColor());

        square.addEventListener("click", function() {
            if (gameStarted) {
                if (score > 0) {
                    score--;
                    scoreDisplay.textContent = "Score: " + score;
                }
                svg.removeChild(square);
            }
        });

        svg.appendChild(square);
        shapes.push({ element: square, dx: Math.random() * 2 - 1, dy: Math.random() * 2 - 1 });
    }

    function moveShapes() {
        shapes.forEach(shape => {
            const element = shape.element;
            let x = parseFloat(element.getAttribute("cx") || element.getAttribute("x"));
            let y = parseFloat(element.getAttribute("cy") || element.getAttribute("y"));
            const dx = shape.dx;
            const dy = shape.dy;

            if (element.tagName === "circle") {
                x += dx;
                y += dy;
                element.setAttribute("cx", x);
                element.setAttribute("cy", y);
            } else if (element.tagName === "rect") {
                x += dx;
                y += dy;
                element.setAttribute("x", x);
                element.setAttribute("y", y);
            }

            // Reverse direction if the shape reaches the edges of the SVG
            if (x < 0 || x > 500) {
                shape.dx *= -1;
            }
            if (y < 0 || y > 300) {
                shape.dy *= -1;
            }
        });
    }

    function updateGame() {
        moveShapes();
        requestAnimationFrame(updateGame);
    }

    function startGame() {
        if (!gameStarted) {
            gameStarted = true;
            score = 0;
            scoreDisplay.textContent = "Score: " + score;

            gameInterval = setInterval(function() {
                createRandomCircle();
                createRandomSquare();
            }, 1000); // Create shapes every second

            updateGame(); // Start the game loop
        }
    }

    startButton.addEventListener("click", startGame);
});
