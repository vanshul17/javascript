document.addEventListener('DOMContentLoaded', function() {
    const firstButton = document.getElementById('first-button');
    const secondButton = document.getElementById('second-button');
    const thirdButton = document.getElementById('third-button');
    const inputElement = document.getElementById('input-element');
    const copyrightNotice = document.getElementById('copyright-notice');

    firstButton.addEventListener('click', handleFirstButtonClick);
    secondButton.addEventListener('click', handleSecondButtonClick);
    thirdButton.addEventListener('click', handleThirdButtonClick);

    function handleFirstButtonClick() {
        const content = 'My AJAX Assignment - #000924316, Vanshul Vanshul';
        appendContentToResponse(content, 'first-output'); // Append new content to first output container
    }

    function handleSecondButtonClick() {
        const choice = inputElement.value;
        fetchData(`https://csunix.mohawkcollege.ca/~adams/10259/a6_responder.php?choice=${choice}`, 'GET', null)
            .then(response => response.json())
            .then(data => {
                const container = document.getElementById('second-output');
                container.innerHTML = ''; // Clear previous content
                data.forEach(item => {
                    const div = createResponseDiv(item);
                    container.appendChild(div); // Append new content to correct container
                });
                updateCopyrightNotice(choice);
            })
            .catch(error => console.error('Error:', error));
    }

    function handleThirdButtonClick() {
        const choice = inputElement.value;
        const formData = new FormData();
        formData.append('choice', choice);
        fetchData('https://csunix.mohawkcollege.ca/~adams/10259/a6_responder.php', 'POST', formData)
            .then(response => response.json())
            .then(data => {
                const container = document.getElementById('third-output');
                container.innerHTML = ''; // Clear previous content
                const table = createResponseTable(data);
                container.appendChild(table); // Append new content to correct container
                updateCopyrightNotice(choice);
            })
            .catch(error => console.error('Error:', error));
    }

    function fetchData(url, method, data) {
        return fetch(url, {
            method: method,
            body: data
        }).then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response;
        });
    }

    function createResponseDiv(item) {
        const div = document.createElement('div');
        div.classList.add('col');
        div.innerHTML = `
            <div class="card">
                <h2 class="card-header">${item.series}</h2>
                <img src="${item.url}" class="card-img-top" alt="${item.name}">
                <div class="card-body">
                    <p class="card-text">${item.name}</p>
                </div>
            </div>
        `;
        return div;
    }

    function createResponseTable(data) {
        const table = document.createElement('table');
        table.classList.add('table');

        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');
        const nameHeader = document.createElement('th');
        nameHeader.textContent = 'Name';
        const seriesHeader = document.createElement('th');
        seriesHeader.textContent = 'Series';
        const linkHeader = document.createElement('th');
        linkHeader.textContent = 'Link';
        headerRow.appendChild(nameHeader);
        headerRow.appendChild(seriesHeader);
        headerRow.appendChild(linkHeader);
        thead.appendChild(headerRow);
        table.appendChild(thead);

        const tbody = document.createElement('tbody');
        data.forEach((item, index) => {
            const row = document.createElement('tr');
            const nameCell = document.createElement('td');
            nameCell.textContent = item.name;
            const seriesCell = document.createElement('td');
            seriesCell.textContent = item.series;
            const linkCell = document.createElement('td');
            const link = document.createElement('a');
            link.href = item.url;
            link.textContent = item.url;
            linkCell.appendChild(link);
            row.appendChild(nameCell);
            row.appendChild(seriesCell);
            row.appendChild(linkCell);
            tbody.appendChild(row);

            if (index % 2 === 0) {
                row.classList.add('row-color-even');
            } else {
                row.classList.add('row-color-odd');
            }
        });
        table.appendChild(tbody);
        return table;
    }

    function appendContentToResponse(content, containerId) {
        const container = document.getElementById(containerId);
        const h1Element = document.createElement('h1');
        h1Element.textContent = content;
        container.appendChild(h1Element);
    }

    function clearResponseContainer() {
        document.getElementById('first-output').innerHTML = '';
        document.getElementById('second-output').innerHTML = '';
        document.getElementById('third-output').innerHTML = '';
    }

    function updateCopyrightNotice(choice) {
        const copyrightText = choice === 'mario' ?
            'Game trademarks and copyrights are properties of their respective owners. Nintendo properties are trademarks of Nintendo. © 2019 Nintendo.' :
            'Star Wars © & TM 2022 Lucasfilm Ltd. All rights reserved. Visual material © 2022 Electronic Arts Inc.';
        copyrightNotice.textContent = copyrightText;
    }
});
