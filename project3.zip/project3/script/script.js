document.addEventListener('DOMContentLoaded', function () {
    const images = [
        ["img1_1.jpg", "img1_2.jpg", "img1_3.jpg"],
        ["img2_1.jpg", "img2_2.jpg", "img2_3.jpg"],
        ["img3_1.jpg", "img3_2.jpg", "img3_3.jpg"]
    ];

    const imageTags = document.querySelectorAll('#image-container img');
    const refreshInput = document.getElementById('refreshInput');
    const randomizeButton = document.getElementById('randomizeButton');
    const countdownTimer = document.getElementById('countdownTimer');
    const imageCounter = document.getElementById('imageCounter');

    let refreshTime = 5000;
    let countdownInterval;
    let changeCount = 0;

    function getRandomImageSrc() {
        const category = Math.floor(Math.random() * images.length);
        const image = Math.floor(Math.random() * images[category].length);
        return "images/" + images[category][image];
    }

    function updateCountdownTimerStyle(timeLeft) {
        if (timeLeft <= (refreshTime / 10000 * 5)) {
            countdownTimer.style.color = "black";
            countdownTimer.style.backgroundColor = "red";
        } else if (timeLeft <= 0) {
            countdownTimer.style.color = "white";
            countdownTimer.style.backgroundColor = "blue";
        } else {
            countdownTimer.style.color = "green";
            countdownTimer.style.backgroundColor = "#fff";
        }
    }

    function startTimer() {
        let timeLeft = refreshTime / 1000;

        countdownInterval = setInterval(() => {
            timeLeft -= 0.1;
            countdownTimer.textContent = timeLeft.toFixed(1);

            updateCountdownTimerStyle(timeLeft);

            if (timeLeft <= 0) {
                clearInterval(countdownInterval);
                countdownTimer.textContent = "0.0";
                selectRandomImages();
                resetTimer();
                changeCount += 3;
                imageCounter.textContent = `Image Changes: ${changeCount}`;
            }
        }, 100);
    }

    function resetTimer() {
        clearInterval(countdownInterval);
        countdownTimer.textContent = (refreshTime / 1000).toFixed(1);
        startTimer();
    }

    function selectRandomImages() {
        imageTags.forEach(img => {
            img.src = getRandomImageSrc();
        });
    }

    randomizeButton.addEventListener('click', () => {
        selectRandomImages();
        changeCount += 3;
        imageCounter.textContent = `Image Changes: ${changeCount}`;
    });

    refreshInput.addEventListener('change', function () {
        const newTime = parseInt(refreshInput.value);
        if (!isNaN(newTime) && newTime >= 500 && newTime <= 10000) {
            refreshTime = newTime;
            resetTimer();
        } else {
            alert("Please enter a valid number between 500 and 10000.");
        }
    });

    selectRandomImages();
    startTimer();
});
